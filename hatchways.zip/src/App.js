import './App.css';
import StudentList from './components/StudentsList';

function App() {
  return (
    <div className="App">
      <StudentList/>
    </div>
  );
}

export default App;
